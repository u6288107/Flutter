package com.example.push_agr

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
