package com.example.named_route

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
