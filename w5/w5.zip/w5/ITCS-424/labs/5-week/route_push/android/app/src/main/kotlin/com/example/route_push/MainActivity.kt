package com.example.route_push

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
